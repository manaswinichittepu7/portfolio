# Welcome to My Lung Cancer Prediction Project

This JupyterBook showcases my end-to-end machine learning project, including my resume, final code, experiments, and deployed apps.

## Sections

- **Resume**: Learn about my professional background and skills.
- **Project Video**: Watch an in-depth explanation of my project.
- **Code**: Dive into the Python implementation of my project.
- **Experiments**: View MLFlow experiments hosted on DagsHub.
- **Streamlit App**: Interact with my deployed Streamlit app.
- **Docker Hub**: Access the Docker container for the API.

---

### Links
- [Streamlit App](https://manaswinichittepu7-python-proj-app-ce6uoo.streamlit.app/)
- [MLFlow Experiments on DagsHub](https://dagshub.com/manaswini.chittepu4/MANASWINI_PROJECT/experiments)
- [MLFlow Dashboard](https://dagshub.com/manaswini.chittepu4/MANASWINI_PROJECT.mlflow/#/experiments/3?searchFilter=&orderByKey=attributes.start_time&orderByAsc=false&startTime=ALL&lifecycleFilter=Active&modelVersionFilter=All+Runs&datasetsFilter=W10%3D)
- [Docker Hub Container](https://hub.docker.com/repository/docker/mchittep/lung-cancer-prediction-api/general)
