# Docker Hub

Access the Docker container repository:

- [Docker Hub Container](https://hub.docker.com/repository/docker/mchittep/lung-cancer-prediction-api/general)
